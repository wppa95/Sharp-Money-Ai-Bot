"""
alerts_multiplatform.py — Alert formatters for multi-platform market engine.

New alert types:
  format_steam_multibook_alert  — coordinated steam across DraftKings/FanDuel/etc.
  format_inefficiency_alert     — one book deviating from cross-book consensus
  format_clv_opportunity_alert  — current price better than projected close
  format_clv_result_alert       — CLV result after event closes
  format_underdog_change_alert  — Underdog line change or removed prop
  format_underdog_new_prop_alert — first-appearance Underdog prop
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional


def _format_game_time_et(dt: datetime) -> str:
    """Convert a naive-UTC datetime to a readable 12-hour ET string.

    Returns e.g. ``"8:40 PM ET"`` for Telegram display.
    Falls back to ``"HH:MM UTC"`` if the zoneinfo conversion fails.
    UTC is kept internally everywhere; this is display-only.
    """
    try:
        from zoneinfo import ZoneInfo
        dt_et = dt.replace(tzinfo=ZoneInfo("UTC")).astimezone(ZoneInfo("America/New_York"))
        # %-I strips the leading zero on Linux ("8:40 PM ET" not "08:40 PM ET")
        return dt_et.strftime("%-I:%M %p ET")
    except Exception:
        return dt.strftime("%H:%M UTC")


def _line_label(line: float) -> str:
    """General line-level reference label — context only, not a difficulty rating."""
    if line <= 0.5:
        return "🟢 Low Line / Goblin Discount"
    elif line <= 1.5:
        return "⚪ Standard Line"
    else:
        return "🔴 Higher Difficulty Line"

from alerts import EMOJI, _div, format_odds, format_probability, RiskFactor
from engine.consensus import ConsensusResult, MarketInefficiency
from engine.clv import CLVOpportunity, CLVResult

# ── V3.4 Bet Quality star + priority helpers ───────────────────────────────────

_BQ_STAR_BANDS = ((100, 5), (80, 4), (70, 3), (40, 2))  # (min_bq, stars)

def _bq_stars(bq: int) -> str:
    """Star display from Bet Quality (decision.confidence).

    V3.4 mapping (independent of raw market score):
      100     → ★★★★★
      80–99   → ★★★★☆
      70–79   → ★★★☆☆
      40–69   → ★★☆☆☆
      0–39    → ★☆☆☆☆
    """
    n = 1
    for min_bq, stars in _BQ_STAR_BANDS:
        if bq >= min_bq:
            n = stars
            break
    return "★" * n + "☆" * (5 - n)


def _bq_priority_label(bq: int, direction: str = "", sport: str = "") -> str:
    """Priority/actionability label for a given Bet Quality score.

    Classification:
      80+   → 💪 STRONG BET (OVER) / 💪 STRONG BET (UNDER for Tier 2 MLB/NFL)
              → ⚠️ note: Tier 1 UNDER uses the separate 🔥 STRONG UNDER standalone label
      75–79 → 🟢 ACTIONABLE
      70–74 → 👀 WATCHLIST ONLY
      <70   → (not shown; would not reach alert formatter)

    STRONG UNDER (🔥) is a Tier 1-only standalone label handled in the caller.
    For Tier 2 (MLB/NFL) UNDER picks, use 💪 STRONG BET to avoid confusion.
    """
    _tier2_sport = sport.upper() in {"MLB", "NFL"}
    if bq >= 80:
        # Tier 1 UNDER keeps "💪 STRONG UNDER" inline priority label.
        # Tier 2 (MLB/NFL) UNDER avoids "STRONG UNDER" — spec reserves that for Tier 1 only.
        if direction == "UNDER":
            return "💪 STRONG BET" if _tier2_sport else "💪 STRONG UNDER"
        return "💪 STRONG BET"
    elif bq >= 75:
        return "🟢 ACTIONABLE"
    elif bq >= 70:
        return "👀 WATCHLIST ONLY"
    return ""


# ── Multi-book steam alert ─────────────────────────────────────────────────────

def format_steam_multibook_alert(
        event: str,
        selection: str,
        sport: str,
        market_type: str,
        steam_score: int,
        steam_direction: str,
        books_moved: list[str],
        opening_odds: int,
        current_odds: int,
        *,
        consensus_odds: Optional[int] = None,
        
        sharp_books: Optional[list[str]] = None,
        risk_factors: Optional[list[RiskFactor]] = None,
    ) -> str:
    """
    Format a cross-platform steam alert spanning DraftKings, FanDuel, and
    other registered sportsbooks. Shows book attribution alongside the score.
    """
    from alerts import identify_sharp_books, compute_steam_risk_factors
    from models import AlertType, SteamAlert, Sport, MarketType

    if sharp_books is None:
        sharp_books = identify_sharp_books(books_moved)

    if risk_factors is None:
        risk_factors = compute_steam_risk_factors(
            books_moved,
            steam_score,
            sharp_books,
        )

    dir_icon  = EMOJI["down"] if steam_direction == "DOWN" else EMOJI["up"]
    dir_label = "FALLING" if steam_direction == "DOWN" else "RISING"
    books_str = ", ".join(books_moved) if books_moved else "—"
    sharp_str = ", ".join(sharp_books) if sharp_books else "None detected"
    change    = current_odds - opening_odds
    filled    = round(steam_score / 10)
    score_bar = "█" * filled + "░" * (10 - filled)

    sport_icon = {
        "NFL": "🏈", "NBA": "🏀", "MLB": "⚾",
        "NHL": "🏒", "UFC": "🥊", "WNBA": "🏀",
    }.get(sport, "🎯")

    consensus_line = (
        f"\n  📊 Consensus:  <code>{format_odds(consensus_odds)}</code>"
        if consensus_odds is not None
        else ""
    )

    if risk_factors is None:
        from alerts import RiskFactor as RF
        risk_factors = []
        if len(books_moved) < 3:
            risk_factors.append(RF("MEDIUM", f"Only {len(books_moved)} books — limited confirmation"))
        if not sharp_books:
            risk_factors.append(RF("MEDIUM", "No sharp books in movers"))
        if steam_score < 70:
            risk_factors.append(RF("LOW", f"Moderate steam score ({steam_score}/100)"))

    parts = [
        f"🔥 <b>MULTI-BOOK STEAM ALERT</b> 🔥",
        "",
        f"{sport_icon} <b>{sport}</b>  ·  {market_type}",
        f"📋 <b>{event}</b>",
        "",
        _div(),
        f"{dir_icon} <b>{selection}</b>  —  odds {dir_label}",
        f"  Opening:   <code>{format_odds(opening_odds)}</code>",
        f"  Current:   <code>{format_odds(current_odds)}</code>",
        f"  Change:    <code>{format_odds(change)}</code>{consensus_line}",
        _div(),
        "",
        f"{EMOJI['fire']} <b>Steam Score:  {steam_score}/100</b>",
        f"  <code>[{score_bar}]</code>",
        "",
        f"📚 <b>Books Moved</b>  ({len(books_moved)})",
        f"  All:      {books_str}",
        f"  ⚡ Sharp:  {sharp_str}",
        "",
        _div(),
        *_risk_section(risk_factors),
        "",
        f"{EMOJI['clock']} <i>{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}</i>",
    ]
    return "\n".join(parts)


# ── Market inefficiency alert ──────────────────────────────────────────────────

def format_inefficiency_alert(
        ineff: MarketInefficiency,
        consensus: ConsensusResult,
        *,
        risk_factors: Optional[list[RiskFactor]] = None,
    ) -> str:
    """
    Format an alert for a book offering better-than-consensus odds.
    Positive deviation = value opportunity (book hasn't moved yet).
    """
    sport_icon = { 
        "NFL": "🏈", "NBA": "🏀", "MLB": "⚾",
        "NHL": "🏒", "UFC": "🥊", "WNBA": "🏀",
    }.get(ineff.sport, "🎯")

    sign = "+" if ineff.deviation > 0 else ""
    consensus_str = format_odds(ineff.consensus_odds)
    offered_str   = format_odds(ineff.offered_odds)

    value_label = "📈 BOOK LAGGING CONSENSUS" if ineff.is_value else "📉 BOOK AHEAD OF CONSENSUS"

    if risk_factors is None:
        from alerts import RiskFactor as RF
        risk_factors = []
        if consensus.book_count < 3:
            risk_factors.append(RF("MEDIUM", f"Only {consensus.book_count} books in consensus — thin sample"))
        if ineff.abs_deviation < 15:
            risk_factors.append(RF("LOW", f"Small deviation ({ineff.abs_deviation}¢) — may close quickly"))

    parts = [
        f"📊 <b>MARKET INEFFICIENCY DETECTED</b>",
        "",
        f"{sport_icon} <b>{ineff.sport}</b>  ·  {ineff.market_type}",
        f"📋 <b>{ineff.event}</b>",
        "",
        _div(),
        f"{value_label}",
        f"  <b>Book:</b>       {ineff.sportsbook}",
        f"  <b>Selection:</b>  {ineff.selection}",
        f"  <b>Offered:</b>    <code>{offered_str}</code>",
        f"  <b>Consensus:</b>  <code>{consensus_str}</code>",
        f"  <b>Deviation:</b>  <code>{sign}{ineff.deviation}</code> cents",
        "",
        f"📚 <b>Books in consensus:</b> {consensus.book_count}",
        f"  Range: <code>{format_odds(consensus.min_odds)}</code> – <code>{format_odds(consensus.max_odds)}</code>",
        f"  Others: {', '.join(b for b in consensus.books if b != ineff.sportsbook)}",
        "",
        _div(),
        "",
        f"{EMOJI['clock']} <i>{ineff.detected_at.strftime('%Y-%m-%d %H:%M UTC')}</i>",
    ]
    return "\n".join(parts)


# ── CLV opportunity alert (current price ahead of projected close) ─────────────

def format_clv_opportunity_alert(
    opp: CLVOpportunity,
    *,
    risk_factors: Optional[list[RiskFactor]] = None,
) -> str:
    """
    Format an alert when a book's current price is better than the projected
    closing line — act now before it closes.
    """
    sport_icon = {
        "NFL": "🏈", "NBA": "🏀", "MLB": "⚾",
        "NHL": "🏒", "UFC": "🥊", "WNBA": "🏀",
    }.get(opp.sport, "🎯")

    curr_str  = format_odds(opp.current_odds)
    close_str = format_odds(opp.projected_close)
    lead_sign = "+" if opp.clv_lead >= 0 else ""

    if risk_factors is None:
        from alerts import RiskFactor as RF
        risk_factors = []
        if opp.books_count < 3:
            risk_factors.append(RF("MEDIUM", f"Projected close from {opp.books_count} books — thin sample"))
        if opp.clv_lead < 10:
            risk_factors.append(RF("LOW", f"Modest lead ({opp.clv_lead}¢) — may close before action"))

    parts = [
        f"💎 <b>CLV OPPORTUNITY — ACT NOW</b>",
        "",
        f"{sport_icon} <b>{opp.sport}</b>  ·  {opp.market_type}",
        f"📋 <b>{opp.event}</b>",
        "",
        _div(),
        f"⚡ <b>{opp.selection}</b>",
        f"  <b>Book:</b>            {opp.sportsbook}",
        f"  <b>Current Price:</b>   <code>{curr_str}</code>",
        f"  <b>Projected Close:</b> <code>{close_str}</code>",
        f"  <b>CLV Lead:</b>        <code>{lead_sign}{opp.clv_lead}</code> cents ahead",
        "",
        f"📚 <b>Consensus from {opp.books_count} books</b>",
        f"<i>Book hasn't moved yet — price should close closer to {close_str}</i>",
        "",
        _div(),
        "",
        f"{EMOJI['clock']} <i>{opp.detected_at.strftime('%Y-%m-%d %H:%M UTC')}</i>",
    ]
    return "\n".join(parts)


# ── CLV result alert (post-close performance) ──────────────────────────────────

def format_clv_result_alert(result: CLVResult) -> str:
    """Format a CLV result for a bet/alert that has now closed."""
    sign    = "+" if result.clv_pct >= 0 else ""
    clv_str = f"{sign}{result.clv_pct:.2f}%"
    beat    = "✅ Beat the close" if result.beat_close else "❌ Missed the close"

    parts = [
        f"{result.clv_emoji} <b>CLV RESULT — {beat}</b>",
        "",
        f"⚡ <b>{result.selection}</b>",
        "",
        _div(),
        f"  <b>Bet Odds:</b>    <code>{format_odds(result.bet_odds)}</code>",
        f"  <b>Closing Odds:</b> <code>{format_odds(result.closing_odds)}</code>",
        f"  <b>CLV:</b>          <code>{clv_str}</code>  ({result.clv_grade})",
        f"  <b>Odds Shift:</b>   <code>{'+' if result.clv_proxy >= 0 else ''}{result.clv_proxy}</code> cents",
    ]

    if result.notes:
        parts += ["", f"<i>{result.notes}</i>"]

    parts += [
        "",
        f"{EMOJI['clock']} <i>{result.computed_at.strftime('%Y-%m-%d %H:%M UTC')}</i>",
    ]
    return "\n".join(parts)


# ── Underdog line change alert ─────────────────────────────────────────────────

def _format_decision_block(
    decision: Optional[object],
    line: Optional[float] = None,
) -> str:
    """
    Format the full OVER / UNDER / PASS evaluation block for Underdog alerts.

    Shows tier, confidence, all per-window hit-rate statistics, and a reason.
    When *line* is supplied and the recommendation is OVER or UNDER, a
    "📌 Suggested Play: OVER/UNDER X.X" line is added immediately after the
    recommendation so the actionable play is always visible at a glance.
    Returns an empty string when *decision* is None.
    """
    if decision is None:
        return ""

    rec       = getattr(decision, "recommendation", "PASS")
    emoji     = getattr(decision, "recommendation_emoji", lambda: "⚪")()
    tier_disp = getattr(decision, "tier_display",         lambda: "—")()
    conf      = getattr(decision, "confidence_display",   lambda: "—")()
    reason    = getattr(decision, "reason", "")
    avg_disp  = getattr(decision, "avg_vs_line_display",  lambda: "N/A")()

    win_fn = getattr(decision, "window_display", None)

    def _w(g, o, u, r, a) -> str:
        """Render one evidence row."""
        if win_fn and callable(win_fn):
            return win_fn(g, o, u, r, a)
        if g is None or r is None:
            return "N/A"
        rate_str = f"{r:.0%}"
        avg_str  = f"  avg {a:.1f}" if a is not None else ""
        return f"{o}/{g} ({rate_str}){avg_str}"

    def _a(name):
        return getattr(decision, name, None)

    is_pick = rec != "PASS"

    # Suggested Play — shown first so the actionable line is immediately visible.
    play_line = (
        f"\n📌 <b>Suggested Play:</b>   {rec} <code>{line:.1f}</code>"
        if (is_pick and line is not None) else ""
    )

    tier_line = f"\n   {tier_disp}" if is_pick else ""
    # Bet Quality = How strong is the actual recommendation?
    # Kept separate from Market Quality (how reliable is the market data).
    conf_line = (
        f"\n   <b>Bet Quality:</b>    {conf}"
        f"  <i>(how strong is the actual recommendation)</i>"
        if is_pick else ""
    )

    if is_pick:
        evidence_block = (
            f"\n\n📊 <b>Evidence:</b>"
            f"\n   <b>L5:</b>          {_w(_a('l5_games'),     _a('l5_over'),     _a('l5_under'),     _a('l5_hit_rate'),     _a('l5_avg'))}"
            f"\n   <b>L10:</b>         {_w(_a('l10_games'),    _a('l10_over'),    _a('l10_under'),    _a('l10_hit_rate'),    _a('l10_avg'))}"
            f"\n   <b>L20:</b>         {_w(_a('l20_games'),    _a('l20_over'),    _a('l20_under'),    _a('l20_hit_rate'),    _a('l20_avg'))}"
            f"\n   <b>L30:</b>         {_w(_a('l30_games'),    _a('l30_over'),    _a('l30_under'),    _a('l30_hit_rate'),    _a('l30_avg'))}"
            f"\n   <b>Season:</b>      {_w(_a('season_games'), _a('season_over'), _a('season_under'), _a('season_hit_rate'), _a('season_avg'))}"
            f"\n   <b>H2H:</b>         {_w(_a('h2h_games'),    _a('h2h_over'),    _a('h2h_under'),    _a('h2h_hit_rate'),    _a('h2h_avg'))}"
            f"\n   <b>Avg vs line:</b> {avg_disp}"
        )
    else:
        evidence_block = ""

    reason_block = f"\n\n💬 <b>Reason:</b>\n   <i>{reason}</i>" if reason else ""

    return (
        f"\n\n{_div()}"
        f"\n🎯 <b>Recommendation:</b>  {emoji} {rec}"
        f"{play_line}"
        f"{tier_line}"
        f"{conf_line}"
        f"{evidence_block}"
        f"{reason_block}"
    )


def _format_market_quality_block(market_quality: Optional[object]) -> str:
    """Render the Market Quality section for Underdog alerts (informational).

    Market Quality = How reliable is the market data?
    This is separate from Bet Quality (how strong is the actual recommendation).
    """
    if market_quality is None:
        return ""
    label   = getattr(market_quality, "label",   None)
    score   = getattr(market_quality, "score",   0)
    reasons = getattr(market_quality, "reasons", ())
    if label is None:
        return ""
    label_str  = label.value if hasattr(label, "value") else str(label)
    filled     = round(score / 10)
    bar        = "█" * filled + "░" * (10 - filled)
    icon       = {"ELITE": "🥇", "STRONG": "🥈", "HIGH": "🥈", "MEDIUM": "🥉", "LOW": "⚠️"}.get(label_str, "📊")
    reason_str = "  •  ".join(reasons) if reasons else "Standard market"
    return (
        f"\n\n{icon} <b>Market Quality:</b>  {label_str}  "
        f"<code>[{bar}]</code>  {score}/100"
        f"\n   <i>How reliable is the market data?  {reason_str}</i>"
    )


def _validate_final_tier(
    tier: str,
    conf: int,
    intelligence_trace: Optional[dict],
) -> str:
    """
    Final tier validation gate — runs before Telegram formatting.

    Ensures the displayed recommendation tier is consistent with actual
    confidence score, role stability, and risk signals.  Only downgrades
    — never upgrades.

    Rules
    -----
        S-tier requires:
      • Confidence ≥ 80  (79/100 confidence should not be labeled S-tier)

    Role/playtime no longer affects tier.

    Parameters
    ----------
    tier               : Raw tier string from UDBetDecision ("S" | "A" | "B" | "PASS")
    conf               : Overall confidence score 0-100
    intelligence_trace : prop_intelligence trace dict (optional)
    """
    if tier not in ("S", "A", "B"):
        return tier

    validated = tier

    # Gate 1: S-tier requires confidence ≥ 80
    if validated == "S" and conf < 80:
        validated = "A"

    # Gate 2 (role-based) removed — role/playtime is not reliable across sports.
    return validated


def _format_market_pressure_block(market_pressure: Optional[object]) -> str:
    """Render the Market Pressure warning section (display-only, never gates alerts)."""
    if market_pressure is None:
        return ""
    if not getattr(market_pressure, "has_pressure", False):
        return ""
    level   = getattr(market_pressure, "pressure_level", "NONE")
    reasons = getattr(market_pressure, "reasons",         ())
    icon       = {"HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🔵"}.get(level, "⚪")
    reason_str = "  •  ".join(reasons) if reasons else ""
    text = f"\n\n{icon} <b>Market Pressure:</b>  {level}"
    if reason_str:
        text += f"\n   <i>{reason_str}</i>"
    return text


def _format_available_lines_block(
    ud_line: Optional[float],
    pp_line: Optional[float] = None,
    dk_line: Optional[float] = None,
    fd_line: Optional[float] = None,
) -> str:
    """
    Render a 📊 Available Lines block showing only providers with real data.
    Providers with no current data are omitted entirely.
    """
    lines = ["\n\n📊 <b>Available Line</b>" if (
        sum(v is not None for v in [pp_line, ud_line, dk_line, fd_line]) == 1
    ) else "\n\n📊 <b>Available Lines</b>"]

    if pp_line is not None:
        lines.append(f"\n🟣 PrizePicks:  <code>{pp_line:.1f}</code>")
    if ud_line is not None:
        lines.append(f"\n🐶 Underdog:    <code>{ud_line:.1f}</code>")
    if dk_line is not None:
        lines.append(f"\n🎰 DraftKings:  <code>{dk_line:.1f}</code>")
    if fd_line is not None:
        lines.append(f"\n🦊 FanDuel:     <code>{fd_line:.1f}</code>")

    return "".join(lines)


def _format_analyst_inline_block(
    player_name: str,
    stat_type: str,
    sport: str,
    line: float,
    score: "Optional[object]",
    decision: "Optional[object]",
    intelligence_trace: "Optional[dict]",
) -> str:
    """
    Generate a compact analyst narrative block for Telegram alerts.

    Calls engine.analyst.format_analyst_alert_block — which is a pure function
    that builds the narrative from stored decision artifacts.  Returns "" for
    PASS/removal decisions, or when the import fails.

    Applies the final tier validation gate (_validate_final_tier) so the
    analyst block reflects a consistent tier/confidence/role assessment.
    A mismatch note is appended when the gate downgrades the tier.
    """
    if decision is None:
        return ""
    rec       = getattr(decision, "recommendation", None)
    raw_tier  = getattr(decision, "decision_tier", "B") or "B"
    conf      = getattr(decision, "confidence", 0) or 0
    rlvl      = "MEDIUM"
    if score is not None:
        # Derive risk from stars: 5=LOW, 4=LOW, 3=MEDIUM, 2/1=HIGH
        stars = getattr(score, "stars", 3) or 3
        rlvl  = "LOW" if stars >= 4 else "MEDIUM" if stars >= 3 else "HIGH"

    # Apply final tier validation gate before passing to analyst
    validated_tier = _validate_final_tier(raw_tier, int(conf), intelligence_trace)
    tier_note = ""
    if validated_tier != raw_tier:
        tier_note = (
            f"\n\n⚠️ <i>Tier adjusted {raw_tier}→{validated_tier}: "
            f"confidence {conf}/100 does not support {raw_tier}-tier.</i>"
        )

    try:
        from engine.analyst import format_analyst_alert_block
        block = format_analyst_alert_block(
            player_name        = player_name,
            stat_type          = stat_type,
            sport              = sport or "UNKNOWN",
            line               = float(line),
            decision_rec       = rec,
            decision_tier      = validated_tier,
            confidence         = int(conf),
            risk_level         = rlvl,
            intelligence_trace = intelligence_trace,
        )
        return block + tier_note
    except Exception:
        return ""


def _format_intelligence_block(trace: "Optional[dict]") -> str:
    """
    Render a 🔍 Intelligence section from a prop_intelligence trace dict.

    The trace is stored in Candidate.decision_trace["prop_intelligence"] and
    contains role (label, stability, trend, summary) and matchup (label, signal,
    reasoning) data computed by engine.prop_intelligence.

    Returns an empty string when trace is None or missing the expected keys.
    """
    if not trace:
        return ""

    role    = trace.get("role",    {}) or {}
    matchup = trace.get("matchup", {}) or {}

    role_label   = (role.get("label")   or "").strip()
    role_summary = (role.get("summary") or "").strip()
    role_trend   = (role.get("trend")   or "Stable").strip()
    match_label  = (matchup.get("label")   or "").strip()
    match_rsns   = matchup.get("reasoning") or []

    # Hit rate summary from historical windows
    historical = trace.get("historical", {}) or {}
    windows    = historical.get("windows", {}) or {}
    _hr_parts: list[str] = []
    for wk in ("l5", "l10", "l20"):
        w = windows.get(wk)
        if w and isinstance(w, dict) and (w.get("n") or 0) >= 3:
            pct = round((w.get("hit_rate") or 0) * 100)
            _hr_parts.append(f"<b>{wk.upper()}:</b> {pct}%")
    _ss = historical.get("sample_strength")

    if not role_label and not match_label and not _hr_parts:
        return ""

    lines = ["\n\n🔍 <b>Intelligence</b>"]

    # Hit rates row
    if _hr_parts:
        ss_str = f"  <i>(ss:{_ss})</i>" if _ss is not None else ""
        lines.append(f"\n   📊 {' | '.join(_hr_parts)}{ss_str}")

            # Role / playtime display removed — not reliable across all sports.

    if match_label:
        match_icon = {
            "Favorable": "✅", "Neutral": "➖",
            "Tough": "⚠️",    "Difficult": "⚠️",
        }.get(match_label, "📊")
        lines.append(f"\n   {match_icon} <b>Matchup:</b>  {match_label}")
        # reasoning is stored as a string (not a list) — display as single bullet
        rsn_text = ""
        if isinstance(match_rsns, str):
            rsn_text = match_rsns.strip()
        elif isinstance(match_rsns, (list, tuple)):
            rsn_text = match_rsns[0].strip() if match_rsns else ""
        if rsn_text:
            lines.append(f"\n      <i>• {rsn_text}</i>")

    return "".join(lines)


def _market_availability_status(game_time: Optional[datetime]) -> str:
    """Return availability label based on time until game start."""
    if game_time is None:
        return "🟢 AVAILABLE NOW"
    gt = game_time.replace(tzinfo=None)
    mins_until = (gt - datetime.utcnow()).total_seconds() / 60
    if mins_until <= 0:
        return "🔴 GAME LIVE / CLOSING"
    elif mins_until <= 30:
        return "🟡 CLOSING SOON"
    else:
        return "🟢 AVAILABLE NOW"


def format_underdog_change_alert(
    player_name: str,
    team: str,
    sport: str,
    stat_type: str,
    old_line: float,
    new_line: float,
    game_time: Optional[datetime] = None,
    score: Optional[object] = None,           # UDPropScore — typed as object to avoid circular import
    validation: Optional[object] = None,      # PlayerPropValidation — typed as object
    decision: Optional[object] = None,        # UDBetDecision — typed as object
    market_quality: Optional[object] = None,  # MarketQuality — display context
    market_pressure: Optional[object] = None, # MarketPressureFlag — warning only
    pp_line: Optional[float] = None,          # PrizePicks line if available
    dk_line: Optional[float] = None,          # DraftKings line if available
    fd_line: Optional[float] = None,          # FanDuel line if available
    *,
    removed: bool = False,
    standing: bool = False,                   # True for evidence-driven alerts without line movement
    removal_reason: Optional[str] = None,     # Why prop was removed (removal alerts only)
    opponent: Optional[str] = None,           # Opponent team / player (when available)
    intelligence_trace: Optional[dict] = None, # prop_intelligence trace from decision_trace
    opening_line: Optional[float] = None,     # First ever line from PropLineHistory
    market_confirmation: Optional[dict] = None,  # OddsAPI sportsbook confirmation data
) -> str:
    """Format an alert for an Underdog prop line change or removed prop.

    Now includes an "Available Lines" block showing all 4 providers, and
    separates Market Movement Score from Bet Confidence.

    When *score* (a UDPropScore) is supplied, the grade is shown.
    When *validation* is supplied, a compact history signal line is appended.
    """
    sport_icon = {
        "NFL": "🏈", "NBA": "🏀", "MLB": "⚾",
        "NHL": "🏒", "UFC": "🥊", "WNBA": "🏀",
    }.get(sport, "🎯")

    if removed:
        header         = "🚫 <b>UNDERDOG PROP REMOVED</b>"
        movement_block = f"  🐶 <b>Last Line:</b>  <code>{old_line:.1f}</code>"
    elif standing:
        header         = "🎯 <b>ACTIONABLE BET PICK</b>"
        movement_block = (
            f"📊 <b>Underdog Line</b>\n"
            f"  🐶 <code>{new_line:.1f}</code>  {_line_label(new_line)}"
        )
    else:
        change         = new_line - old_line
        direction_icon = "📈" if change > 0 else "📉"
        header         = "🎯 <b>ACTIONABLE BET PICK</b>"
        change_sign    = "+" if change >= 0 else ""
        movement_block = (
            f"📊 <b>Underdog Line</b>\n"
            f"  🐶 <code>{new_line:.1f}</code>  {_line_label(new_line)}\n"
            f"  Previous:         <code>{old_line:.1f}</code>\n"
            f"  {direction_icon} Move:  <code>{change_sign}{change:.1f}</code>"
        )

    opponent_str = f"\n  <b>vs:</b>      {opponent}" if opponent else ""
    game_str = (
        f"\n  🕐 <b>Game starts:</b>  {_format_game_time_et(game_time)}"
        if game_time else ""
    )

    # Opening line display — show only when different from current and not a removal
    opening_str = ""
    if not removed and opening_line is not None and abs(opening_line - new_line) >= 0.1:
        total_move_sign = "+" if (new_line - opening_line) >= 0 else ""
        opening_str = (
            f"\n  <b>Opened:</b>  <code>{opening_line:.1f}</code>"
            f"  <i>(total move: {total_move_sign}{new_line - opening_line:.1f})</i>"
        )

    # Grade + movement score vs bet confidence separation
    # V3.4: stars and displayed BQ come from decision.confidence, not score.total.
    grade_str = ""
    if score is not None:
        tier      = getattr(score, "tier",          "?")
        total     = getattr(score, "total",          0)
        n_hist    = getattr(score, "n_history",      0)
        move_vel  = getattr(score, "move_velocity",  None)  # market movement component
        # Stars and BQ label from decision.confidence when available; fall back to score
        _bq_conf_g = getattr(decision, "confidence", None) if decision is not None else None
        if _bq_conf_g is not None:
            s_disp    = _bq_stars(int(_bq_conf_g))
            _bq_label = f"BQ {int(_bq_conf_g)}/100"
        else:
            s_disp    = getattr(score, "stars_display", "?" * 5)
            _bq_label = f"{total}/100"

        grade_str = f"\n\n📊 <b>Grade:</b>  <code>{tier}</code>  {s_disp}  <code>{_bq_label}</code>  <i>(n={n_hist})</i>"

        if not removed and move_vel is not None:
            grade_str += (
                f"\n\n📉 <b>Market Movement Score:</b>  <code>{move_vel}/100</code>"
                f"  <i>(how significant is the line move)</i>"
                f"\n🎯 <b>Bet Confidence:</b>         <code>{total}/100</code>"
                f"  <i>(composite: history + movement)</i>"
                f"\n<i>Market activity ≠ betting edge.</i>"
            )

    # Validation block
    validation_str = ""
    if validation is not None and getattr(validation, "has_supporting_data", False):
        validation_str = (
            f"\n💡 <b>History:</b>  "
            f"<code>{getattr(validation, 'rate_summary', lambda: '')()}</code>"
        )

    # Available lines block (all 4 providers)
    avail_block = _format_available_lines_block(
        ud_line = new_line if not removed else old_line,
        pp_line = pp_line,
        dk_line = dk_line,
        fd_line = fd_line,
    )

    _thick = "━" * 18
    _removal_reason_str = ""
    if removed:
        _reason = removal_reason or "Market no longer available from provider"
        _removal_reason_str = f"\n  <b>Removal Reason:</b>  {_reason}"

    # ── Compact alert (decision-first) ──────────────────────────────────────
    change = (new_line - old_line) if not removed else 0.0
    change_sign = "+" if change >= 0 else ""

    # Pick / tier / quality from decision
    rec = getattr(decision, "recommendation", None) if decision else None
    tier = getattr(decision, "decision_tier", None) if decision else None
    conf = getattr(decision, "confidence", None) if decision else None
    if tier is None and score is not None:
        tier = getattr(score, "tier", None)
    if conf is None and score is not None:
        conf = getattr(score, "total", None)

    pick_line = ""
    strong_under_line = ""
    edge_line = ""
    if rec in ("OVER", "UNDER") and not removed:
        pick_emoji = "🟢" if rec == "OVER" else "🔴"
        pick_line = f"📌 <b>PICK:</b>  {pick_emoji} <b>{rec} {new_line:.1f}</b>"
        if tier:
            pick_line += f"   ·   <b>{tier}-Tier</b>"
        if conf is not None:
            _bq_int = int(conf)
            pick_line += f"   ·   Bet Quality <code>{_bq_int}/100</code>  {_bq_stars(_bq_int)}"
            _priority_lbl = _bq_priority_label(_bq_int, direction=rec, sport=sport)
            if _priority_lbl:
                pick_line += f"   ·   {_priority_lbl}"
        # STRONG UNDER signal — Tier 1 sports only (not MLB/NFL).
        # Fires when: UNDER direction + confidence ≥ 30 AND BQ (decision.confidence) ≥ 70.
        # Does NOT promote the prop to S-tier — tier/actionability still determined by confidence.
        _is_tier1_sport = sport.upper() not in {"MLB", "NFL"}
        if (rec == "UNDER"
                and _is_tier1_sport
                and conf is not None
                and int(conf) >= 30
                and int(conf) >= 70):
            strong_under_line = "🔥 <b>STRONG UNDER</b>  <i>(BQ ≥ 70 — verify line on Underdog before placing)</i>"
        elif rec == "UNDER" and conf is not None and int(conf) >= 30:
            strong_under_line = (
                "🔴 <b>Strong UNDER Signal</b>"
                "  <i>(BQ ≥ 30 — verify line on Underdog before placing)</i>"
            )

        # Full hit-history breakdown — show every available window on actionable alerts.
        if not removed:
            reason = (
                (getattr(decision, "reason", None) or "").strip()
                if decision is not None else ""
            )

            _history_windows = [
                ("L5", getattr(decision, "l5_hit_rate", None), getattr(decision, "l5_games", None)),
                ("L10", getattr(decision, "l10_hit_rate", None), getattr(decision, "l10_games", None)),
                ("L20", getattr(decision, "l20_hit_rate", None), getattr(decision, "l20_games", None)),
                ("L30", getattr(decision, "l30_hit_rate", None), getattr(decision, "l30_games", None)),
                ("Season", getattr(decision, "season_hit_rate", None), getattr(decision, "season_games", None)),
            ]

            history_bits = []
            for _label, _rate, _games in _history_windows:
                if _rate is not None and _games and isinstance(_rate, (int, float)):
                    history_bits.append(f"{_label}: {_rate:.0%} ({_games}g)")
                else:
                    history_bits.append(f"{_label}: N/A")

            edge_line = "📊 <b>Hit History:</b>  " + "  ·  ".join(history_bits)

            if reason:
                edge_line += f"\n📌 <b>Reason:</b>  {reason.split('•')[0].strip()[:120]}"

    # Market quality one-liner
    mq_line = ""
    if market_quality is not None and not removed:
        mq_label = getattr(market_quality, "label", None) or getattr(market_quality, "tier", "")
        mq_score = getattr(market_quality, "score", None)
        if mq_label or mq_score is not None:
            mq_line = f"📈 <b>Market:</b>  {mq_label or ''}"
            if mq_score is not None:
                mq_line += f"  <code>{int(mq_score)}/100</code>"

    if removed:
        body_lines = [
            _thick,
            header,
            _thick,
            "",
            f"{sport_icon} <b>{sport} — {stat_type}</b>",
            f"👤 <b>{player_name}</b>",
            "",
            f"🐶 Last line: <code>{old_line:.1f}</code>",
            f"Removal: {removal_reason or 'Market no longer available'}",
            "",
            f"{EMOJI['clock']} <i>{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}</i>",
            "",
            _thick,
        ]
    else:
        # OddsAPI sportsbook confirmation footer (S/A tier only)
        _confirm_line = ""
        if market_confirmation is not None:
            _cn = market_confirmation.get("notes", "")
            if _cn:
                _confirm_line = f"📡 <b>Market Check:</b>  {_cn}"

        body_lines = [
            _thick,
            header,
            _thick,
            "",
            f"{sport_icon} <b>{sport} — {stat_type}</b>",
            f"👤 <b>{player_name}</b>",
            "",
            f"🐶 <b>Line:</b>  <code>{new_line:.1f}</code>   Prev <code>{old_line:.1f}</code>   Move <code>{change_sign}{change:.1f}</code>",
            "",
            pick_line,
            *([strong_under_line] if strong_under_line else []),
        ]
        if edge_line:
            body_lines += ["", edge_line]
        if mq_line:
            body_lines += [mq_line]
        if _confirm_line:
            body_lines += [_confirm_line]
        body_lines += [
            "",
            f"📍 <b>Status:</b>  {_market_availability_status(game_time)}",
            f"{EMOJI['clock']} <i>{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}</i>",
            "",
            _thick,
        ]

    # Drop empty strings from optional lines
    parts = [ln for ln in body_lines if ln is not None]
    return "\n".join(parts)


def format_market_move_detected(
    player_name: str,
    team: str,
    sport: str,
    stat_type: str,
    old_line: float,
    new_line: float,
    game_time: Optional[datetime] = None,
) -> str:
    """Lightweight alert for significant line moves that do not yet qualify as bet picks.

    Fires when Underdog moves a line by ≥ MIN_UNDERDOG_LINE_CHANGE but the prop
    has not passed the full scoring + confidence + tier gate.  Keeps the user
    informed of sharp market movement without implying a betting edge.
    """
    sport_icon = {
        "NFL": "🏈", "NBA": "🏀", "MLB": "⚾",
        "NHL": "🏒", "UFC": "🥊", "WNBA": "🏀",
    }.get(sport, "🎯")

    change = new_line - old_line
    change_sign = "+" if change >= 0 else ""
    direction_icon = "📈" if change > 0 else "📉"

    game_str = (
        f"\n🕐 <b>Game:</b>  {game_time.strftime('%b %d %H:%M')} UTC"
        if game_time else ""
    )

    _thick = "━" * 18
    body_lines = [
        _thick,
        f"{direction_icon} <b>MARKET MOVE DETECTED</b>",
        _thick,
        "",
        f"{sport_icon} <b>{sport} — {stat_type}</b>",
        f"👤 <b>{player_name}</b>",
        "",
        f"🐶 <b>Line:</b>  <code>{old_line:.1f}</code>  →  <code>{new_line:.1f}</code>",
        f"📉 <b>Movement:</b>  <code>{change_sign}{change:.1f}</code>",
        "",
        "📊 <b>Status:</b>  Tracking — evaluating for bet quality",
        "<i>This is a market signal, not yet a bet pick.</i>",
        game_str,
        "",
        f"🕐 <i>{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}</i>",
        "",
        _thick,
    ]
    parts = [ln for ln in body_lines if ln is not None]
    return "\n".join(parts)


# ── Underdog new-prop alert ────────────────────────────────────────────────────

def format_underdog_new_prop_alert(
    player_name: str,
    team: str,
    sport: str,
    stat_type: str,
    line_value: float,
    game_time: Optional[datetime] = None,
    score: Optional[object] = None,           # UDPropScore
    validation: Optional[object] = None,      # PlayerPropValidation
    decision: Optional[object] = None,        # UDBetDecision
    market_quality: Optional[object] = None,  # MarketQuality — display context
    market_pressure: Optional[object] = None, # MarketPressureFlag — warning only
    pp_line: Optional[float] = None,          # PrizePicks line if available
    dk_line: Optional[float] = None,          # DraftKings line if available
    fd_line: Optional[float] = None,          # FanDuel line if available
    *,
    low_line_threshold: float = 1.0,
    opponent: Optional[str] = None,           # Opponent team / player (when available)
    intelligence_trace: Optional[dict] = None, # prop_intelligence trace from decision_trace
    market_confirmation: Optional[dict] = None,  # OddsAPI sportsbook confirmation data
) -> str:
    """Format a 🚨 UNDERDOG PROP LIVE alert for a first-appearance prop.

    Fires when a (player_name, stat_type) pair is seen for the very first
    time AND has sufficient history to justify an immediate alert.
    The validation gate ensures props with no history go to digest only.
    """
    sport_icon = {
        "NFL": "🏈", "NBA": "🏀", "MLB": "⚾",
        "NHL": "🏒", "UFC": "🥊", "WNBA": "🏀",
    }.get(sport, "🎯")

    opponent_str = f"\n  <b>vs:</b>          {opponent}" if opponent else ""
    game_str = (
        f"\n  🕐 <b>Game starts:</b>  {_format_game_time_et(game_time)}"
        if game_time else ""
    )

    # Grade block — V3.4: stars and BQ label from decision.confidence when available
    grade_str = ""
    if score is not None:
        tier   = getattr(score, "tier",         "?")
        total  = getattr(score, "total",         0)
        n_hist = getattr(score, "n_history",     0)
        _bq_conf_np = getattr(decision, "confidence", None) if decision is not None else None
        if _bq_conf_np is not None:
            s_disp    = _bq_stars(int(_bq_conf_np))
            _bq_label = f"BQ {int(_bq_conf_np)}/100"
        else:
            s_disp    = getattr(score, "stars_display", "?" * 5)
            _bq_label = f"{total}/100"
        grade_str = (
            f"\n\n📊 <b>Grade:</b>  <code>{tier}</code>  {s_disp}  "
            f"<code>{_bq_label}</code>"
            f"  <i>(n={n_hist})</i>"
        )

    # Validation block — only show when supporting history is available
    validation_str = ""
    if validation is not None and getattr(validation, "has_supporting_data", False):
        validation_str = (
            f"\n💡 <b>History:</b>  "
            f"<code>{getattr(validation, 'rate_summary', lambda: '')()}</code>"
        )

    # Strong UNDER label — Tier 1 sports only (not MLB/NFL).
    # Fires when: UNDER direction + BQ (decision.confidence) ≥ 70.
    # Does NOT promote the prop to S-tier — tier/actionability determined by confidence.
    _np_rec = getattr(decision, "recommendation", None) if decision is not None else None
    _np_bq  = getattr(decision, "confidence", None)     if decision is not None else None
    _np_sport_up = (sport or "").upper()
    _np_is_tier1 = _np_sport_up not in {"MLB", "NFL"}
    _np_strong_under = ""
    if (_np_rec == "UNDER"
            and _np_is_tier1
            and _np_bq is not None
            and int(_np_bq) >= 70):
        _np_strong_under = "🔥 <b>STRONG UNDER</b>  <i>(BQ ≥ 70 — verify line on Underdog before placing)</i>"
    elif _np_rec == "UNDER" and _np_bq is not None and int(_np_bq) >= 30:
        _np_strong_under = (
            "🔴 <b>Strong UNDER Signal</b>"
            "  <i>(BQ ≥ 30 — verify line on Underdog before placing)</i>"
        )

    # L5 history block — always shown; falls back to N/A when no history available.
    _np_l5     = getattr(decision, "l5_hit_rate", None) if decision is not None else None
    _np_l5g    = getattr(decision, "l5_games",    None) if decision is not None else None
    _np_l5_str = (
        f"📊 <b>L5:</b>  {_np_l5:.0%} ({_np_l5g}g)"
        if (_np_l5 is not None and _np_l5g)
        else "📊 <b>L5:</b>  N/A — no history available"
    )

    # Reason bullets
    reasons = ["• New prop detected"]
    if line_value <= low_line_threshold:
        reasons.append(f"• Low starting line ({line_value} ≤ {low_line_threshold})")
    if score is not None and getattr(score, "stars", 0) >= 3:
        tier = getattr(score, "tier", "?")
        reasons.append(f"• Score qualifies ({tier}-tier)")
    if validation is not None and getattr(validation, "has_supporting_data", False):
        reasons.append(f"• Supporting history available ({getattr(validation, 'n_history', 0)} snapshots)")

    # Available lines block (all 4 providers)
    avail_block = _format_available_lines_block(
        ud_line = line_value,
        pp_line = pp_line,
        dk_line = dk_line,
        fd_line = fd_line,
    )

    _thick = "━" * 18
    parts = [
        _thick,
        "🚨 <b>UNDERDOG PROP LIVE</b>",
        _thick,
        "",
        f"{sport_icon} <b>{sport} — {stat_type}</b>",
        f"👤 <b>{player_name}</b>",
        "",
        _div(),
        avail_block.lstrip("\n"),
        "",
        _div(),
        f"  🐶 <b>Underdog Line:</b>  <code>{line_value:.1f}</code>  {_line_label(line_value)}",
        f"  <b>First Seen:</b>    {datetime.utcnow().strftime('%H:%M UTC')}"
        + opponent_str
        + game_str
        + grade_str
        + f"\n{_np_l5_str}"
        + (_np_strong_under and f"\n{_np_strong_under}" or "")
        + validation_str
        + _format_decision_block(decision, line=line_value)
        + _format_market_quality_block(market_quality)
        + _format_market_pressure_block(market_pressure)
        + _format_intelligence_block(intelligence_trace)
        + _format_analyst_inline_block(
            player_name        = player_name,
            stat_type          = stat_type,
            sport              = sport or "UNKNOWN",
            line               = line_value,
            score              = score,
            decision           = decision,
            intelligence_trace = intelligence_trace,
        ),
        "",
        "<b>Reason:</b>",
        "\n".join(reasons),
        *([f"📡 <b>Market Check:</b>  {market_confirmation['notes']}"]
          if market_confirmation and market_confirmation.get("notes") else []),
        "",
        f"{EMOJI['clock']} <i>{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}</i>",
        "",
        _thick,
    ]
    return "\n".join(parts)


# ── Underdog end-of-cycle new-prop digest ─────────────────────────────────────

def format_underdog_new_prop_cycle_summary(
    new_props: "list[dict]",
    *,
    max_shown: int = 8,
) -> str:
    """Format a 📋 end-of-cycle digest for all new Underdog props detected this cycle.

    Each entry in ``new_props`` is a dict with keys:
      player, stat_type, sport, team, line, score (UDPropScore|None),
      immediate (bool), game_time (datetime|None).

    Sorted display order: 0.5 lines first → line asc → stars desc.
    Immediately-alerted props are marked with ⚡; others with a tier badge.
    """
    if not new_props:
        return ""

    total       = len(new_props)
    n_immediate = sum(1 for p in new_props if p.get("immediate"))
    n_half_line = sum(1 for p in new_props if (p.get("line") or 99.0) <= 0.5)

    def _sort_key(p: dict) -> tuple:
        stars = getattr(p.get("score"), "stars", 0)
        line  = p.get("line") or 99.0
        # 0.5 lines first, then ascending line, then descending stars
        return (0 if line <= 0.5 else 1, line, -stars)

    sorted_props = sorted(new_props, key=_sort_key)
    shown        = sorted_props[:max_shown]
    overflow     = total - len(shown)

    sport_icon = {
        "NFL": "🏈", "NBA": "🏀", "MLB": "⚾",
        "NHL": "🏒", "UFC": "🥊", "WNBA": "🏀",
    }

    parts = [
        f"📋 <b>UNDERDOG NEW PROPS</b>  —  <b>{total}</b> detected",
        "",
        _div(),
        f"  ⚡ Immediate alerts:  <b>{n_immediate}</b>",
        f"  🎯 0.5 lines found:   <b>{n_half_line}</b>",
        "",
        "<b>Top Opportunities</b>",
    ]

    for p in shown:
        score  = p.get("score")
        stars  = getattr(score, "stars_display", "·····") if score else "·····"
        tier   = getattr(score, "tier",          "?")     if score else "?"
        sport  = p.get("sport", "")
        icon   = sport_icon.get(sport, "🎯")
        line   = p.get("line") or 0.0
        marker = "⚡" if p.get("immediate") else f"<code>{tier}</code>"
        parts.append(
            f"  {marker}  {icon} {p['player']} — {p['stat_type']}"
            f"  @{line}  {stars}"
        )

    if overflow > 0:
        parts.append(f"  <i>...and {overflow} more</i>")

    parts += [
        "",
        f"{EMOJI['clock']} <i>{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}</i>",
    ]
    return "\n".join(parts)


# ── /market command response formatter ────────────────────────────────────────

def format_consensus_summary(results: list[ConsensusResult]) -> str:
    """Format a summary of consensus results for the /market command."""
    if not results:
        return (
            f"📊 <b>Market Consensus</b>\n\n"
            f"No cross-book consensus data available.\n"
            f"<i>Data accumulates as connectors poll live odds.</i>"
        )

    ineffs = sum(1 for r in results if r.has_inefficiency)
    total  = len(results)

    parts = [
        f"📊 <b>Market Consensus Summary</b>",
        "",
        f"Markets tracked:      <code>{total}</code>",
        f"With inefficiencies:  <code>{ineffs}</code>",
        "",
        _div(),
    ]

    # Show top markets with inefficiencies first
    sorted_results = sorted(results, key=lambda r: len(r.outliers), reverse=True)
    for cr in sorted_results[:8]:
        ineff_flag = "⚠️" if cr.has_inefficiency else "✅"
        consensus_str = format_odds(cr.consensus_odds)
        parts.append(
            f"{ineff_flag} <b>{cr.selection}</b>\n"
            f"   {cr.event} | {cr.market_type}\n"
            f"   Consensus: <code>{consensus_str}</code> ({cr.book_count} books)"
        )
        if cr.has_inefficiency:
            for ineff in cr.outliers:
                sign = "+" if ineff.deviation > 0 else ""
                parts.append(
                    f"   📌 {ineff.sportsbook}: <code>{format_odds(ineff.offered_odds)}</code>"
                    f" [{sign}{ineff.deviation}]"
                )
        parts.append("")

    return "\n".join(parts)


# ── /clv command response formatter ───────────────────────────────────────────

def format_clv_history(records: list) -> str:
    """Format CLV history records for the /clv command."""
    if not records:
        return (
            f"💎 <b>CLV Performance</b>\n\n"
            f"No CLV records yet.\n"
            f"<i>CLV is computed when alerted markets close.</i>"
        )

    total   = len(records)
    beaten  = sum(1 for r in records if r.clv_pct > 0)
    avg_clv = sum(r.clv_pct for r in records) / total if total > 0 else 0
    sign    = "+" if avg_clv >= 0 else ""

    parts = [
        f"💎 <b>CLV Performance</b>",
        "",
        f"Records:     <code>{total}</code>",
        f"Beat close:  <code>{beaten}/{total}</code>  ({beaten/total*100:.0f}%)",
        f"Avg CLV:     <code>{sign}{avg_clv:.2f}%</code>",
        "",
        _div(),
    ]

    for r in records[:10]:
        bet_sign = "+" if r.clv_pct >= 0 else ""
        emoji = "✅" if r.clv_pct > 0 else "❌"
        parts.append(
            f"{emoji} <b>{r.selection}</b>\n"
            f"   CLV: <code>{bet_sign}{r.clv_pct:.2f}%</code>  "
            f"bet={format_odds(r.bet_odds)} close={format_odds(r.closing_odds)}\n"
            f"   {r.computed_at.strftime('%b %d %H:%M')} UTC"
        )

    return "\n".join(parts)
